﻿using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WPFTutorial
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {

            InitializeComponent();
            blueslid.Value= 0;
            greenSlid.Value= 0;
            redSlid.Value= 0;

            blueblock.Text = "0";
            greeblock.Text = "0";
            redBlock.Text = "0";
            FillWithColor();

        }

        private void blueslid_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            blueblock.Text = blueslid.Value.ToString();
        }
        
        private void greenSlid_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            greeblock.Text = greenSlid.Value.ToString();
        } 
        
        private void redSlid_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            redBlock.Text = redSlid.Value.ToString();
        }



        private void greeblock_TextChanged(object sender, TextChangedEventArgs e)
        {
            
            if ((double.TryParse(greeblock.Text, out double value)) && double.Parse(greeblock.Text) <= 255 && double.Parse(greeblock.Text)>= 0)
            {
                
                FillWithColor();
                greenSlid.Value = value;
            }
            else if (blueblock.Text != "")
                MessageBox.Show("Nesprávný vstup", "ERROR", MessageBoxButton.OK, MessageBoxImage.Error);
        }

        private void redBlock_TextChanged(object sender, TextChangedEventArgs e)
        {
            if ((double.TryParse(redBlock.Text, out double value)) && double.Parse(redBlock.Text) <= 255 && double.Parse(redBlock.Text) >= 0)
            {
                FillWithColor();
                redSlid.Value = value;
            }
            else if (blueblock.Text != "")
                MessageBox.Show("Nesprávný vstup", "ERROR", MessageBoxButton.OK, MessageBoxImage.Error);

        }

        private void blueblock_TextChanged(object sender, TextChangedEventArgs e)
        {
            if ((double.TryParse(blueblock.Text, out double value)) && double.Parse(blueblock.Text) <= 255 && double.Parse(blueblock.Text) >= 0)
            {
                FillWithColor();
                blueslid.Value = value;
            }
            else if(blueblock.Text != "")
                MessageBox.Show("Nesprávný vstup", "ERROR", MessageBoxButton.OK, MessageBoxImage.Error);

        }

        public void FillWithColor()
        {
            SolidColorBrush color = new SolidColorBrush();
            byte red = (byte)redSlid.Value;
            byte green = (byte)greenSlid.Value;
            byte blue = (byte)blueslid.Value;

            color.Color = Color.FromArgb(255, red ,green , blue);
            recColor.Fill = color;

            string hex = $"#{red:X2}{green:X2}{blue:X2}";
            labHex.Content = hex;


        }
    }
}