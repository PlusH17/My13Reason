﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kretk.Model
{
    class Card
    {
        public bool MolePresence { get; set; }
        public Card(bool molePresence) { this.MolePresence = molePresence; }
    }
}
