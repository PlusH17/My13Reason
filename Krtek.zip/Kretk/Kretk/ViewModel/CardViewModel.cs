﻿using Kretk.MVVM;
using Kretk.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kretk.ViewModel
{
    class CardViewModel : ViewModelBase
    {
        public Card Model { get; }

        public CardViewModel(Card card)
        {  Model = card; }

        public bool MolePresence
        {
            get => Model.MolePresence;
            set
            {
                Model.MolePresence = value;
                OnPropertyChanged(); 
            }
        }
    }
}
