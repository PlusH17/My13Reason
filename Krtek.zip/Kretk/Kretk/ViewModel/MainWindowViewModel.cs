﻿using Kretk.Model;
using Kretk.MVVM;
using System;
using System.Collections.ObjectModel;
using System.Windows;
using System.Windows.Input;
using System.Windows.Threading; // Nutné pro DispatcherTimer

namespace Kretk.ViewModel
{
    class MainWindowViewModel : ViewModelBase
    {
        private DispatcherTimer _timer;
        private DispatcherTimer _timerKrtek;
        private bool _isGameRunning = false;
        private int _timeLeft;

        public RelayCommand StartCommand => new RelayCommand(execute => StartGame(), canExecute => !_isGameRunning);
        public RelayCommand CardClickCommand => new RelayCommand(execute => CardClicked(execute as CardViewModel), canExecute => _isGameRunning == true);

        const int CardCount = 16;

        public MainWindowViewModel()
        {
            
            Cards = new ObservableCollection<CardViewModel>();

            _timer = new DispatcherTimer();
            _timer.Interval = TimeSpan.FromSeconds(1); 
            _timer.Tick += Timer_Tick;

            _timerKrtek = new DispatcherTimer();
            _timerKrtek.Interval = TimeSpan.FromMilliseconds(200);
            _timerKrtek.Tick += TimeToKill;



        }

        public ObservableCollection<CardViewModel> Cards { get; set; }
        public int GridSize => (int)Math.Sqrt(Cards.Count);

        public int TimeLeft
        {
            get { return _timeLeft; }
            set { _timeLeft = value; OnPropertyChanged(); }
        }
        private int skore;

        public int Score
        {
            get { return skore; }
            set { skore = value; OnPropertyChanged(); }
        }

        private int dificulty;

        public int Difficulty
        {
            get { return dificulty; }
            set { dificulty = value; OnPropertyChanged(); }
        }

        private int killKrtek;




        public void StartGame()
        {
            killKrtek = 5 - dificulty; //podle nastavene obtížnost se změní čas na zabití krtka
            Cards.Clear();
            CreateGameCards();
            StartKrtek();

            _isGameRunning = true;
            StartTime();
            _timerKrtek.Start();

            Score = 0;
            OnPropertyChanged(nameof(GridSize));
        }

        private void CreateGameCards()
        {
            for (int i = 0; i < CardCount; i++)
            {
                Cards.Add(new CardViewModel(new Card(false)));
            }
        }

        private void StartTime()
        {
            TimeLeft = 60;
            _timer.Start();
        }

        private void Timer_Tick(object sender, EventArgs e)
        {
            if (TimeLeft > 0)
            {
                TimeLeft--;
            }
            else
            {
                EndGame();
            }
        }
        private void TimeToKill(object sender, EventArgs e)
        {

            if (killKrtek > 0)
            {
                killKrtek--;
            }
            else
                SwitchKrtek();


        }

        private int indexkrtka;

        private void SwitchKrtek()
        {
            killKrtek = 5 - dificulty;
            Cards[indexkrtka].MolePresence = false;

            Random rg = new Random();
            int j = rg.Next(0, Cards.Count);
            indexkrtka = j;

            Cards[j].MolePresence = true;
            killKrtek = 5 - dificulty ;
        }
        private void StartKrtek()
        {
            Random rg = new Random();
            int j = rg.Next(Cards.Count - 1);
            indexkrtka = j;
            Cards[j].Model.MolePresence = true;
        }

        private async void CardClicked(CardViewModel clicked)
        {
            if (clicked != null && clicked.MolePresence)
            {
                
                Score++;

                SwitchKrtek();

            }
        }


        private void EndGame()
        {
            _timer.Stop();
            _isGameRunning = false;
            MessageBoxResult result = System.Windows.MessageBox.Show($"Čas vypršel! Získal jsi skóre: {skore}. Chceš hrát další hru?", "Konec hry", System.Windows.MessageBoxButton.YesNo, System.Windows.MessageBoxImage.Question);
            if (result == MessageBoxResult.Yes)
            {
                StartGame();
            }
            else
                System.Windows.Application.Current.Shutdown();
        }
    }
}