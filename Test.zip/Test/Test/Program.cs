﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Test
{
    internal class Program
    {
        static void Main(string[] args)
        {

            ChessBoard board = new ChessBoard();
            Horse horse = new Horse();


            Console.WriteLine("Vstup:");
            string str_number_of_cross = Console.ReadLine();

            int number_of_cross = int.Parse(str_number_of_cross);

            for (int i = 0; i < number_of_cross; i++) // překážky
            {
                string[] str_cross = Console.ReadLine().Split(' ');
                int[] cross_cordation = new int[2];
                for (int j = 0; j < 2; j++)
                {
                    string str = str_cross[j];
                    int cordation = int.Parse(str);
                    cross_cordation[j] = cordation;
                }

                board.cross.Add(cross_cordation);
            }

            string[] str_start = Console.ReadLine().Split(' ');
            int[] horse_start = new int[2];

            horse_start[0] = int.Parse(str_start[0]);
            horse_start[1] = int.Parse(str_start[1]);

            board.start = horse_start;
            horse.startPosition = horse_start;


            string[] str_end = Console.ReadLine().Split(' ');
            int[] horse_end = new int[2];

            horse_end[0] = int.Parse(str_end[0]);
            horse_end[1] = int.Parse(str_end[1]);

            board.end = horse_end;
            horse.endPosition = horse_end;

            board.CreateBoard();
            horse.Init();

            board.Horse = horse;
            horse.board = board;

            MovingHorse(board, horse);
        }

        public static void MovingHorse(ChessBoard chessBoard, Horse horse) 
        {

            bool Horse_Moved = false;
            if (horse.actualPosition == chessBoard.end) //když je kun na konci, je konec
            {
                return;
            }
                
            for (int i = 1; i > 9; i++) //jinak zkoušíme všechny možné kroky kam může jít
            {
                Horse_Moved = horse.CanMove(i);
                if (Horse_Moved == true)
                {
                    MovingHorse(chessBoard, horse);
                }
                
            }
        }
    }

    

    class ChessBoard
    {
        public int[,] board = new int[8,8];
        public int[] start; // s = 5
        public int[] end; // e = 8
        public Horse Horse;

        public List<int[]> cross; // cross = -1

        public void CreateBoard()
        {
            for (int i = 0; i < 8; i++)
            {
                for (int j = 0; j < 8; j++)
                    board[i, j] = 0;
            }

            int start_col = start[0];
            int start_row = start[1];

            board[start_col,start_row] = 5;

            int end_col = end[0];
            int end_row = end[1];

            board[end_col,end_row] = 8;

            for (int i = 0; i < cross.Count; i++)
            {
                int cross_col = cross[i][0];
                int cross_row = cross[i][1];

                board[cross_col, cross_row] = -1;
            }
        }

        

        
    }

    class Horse
    {
        public int[] startPosition;
        public int[] endPosition;

        public int[] actualPosition;
        public int moves; //chtělo by to rozdělit na TryMoves a FinaleMoves, at mužu jedno měnit a zkoušet, druhé nechat být, ale není čas

        public List<int[]> alreadyVisited;
        public List <int> visitedInHowManyMoves; //přidávám vždy stejně jako alreadyVsisited -> stejný index -> udržuju si, v kolika krocích jsem něco navšívila

        public ChessBoard board;

        

        public void Init()
        {
            moves = 0;
            actualPosition = startPosition;
            alreadyVisited.Add(actualPosition);
            visitedInHowManyMoves.Add(moves);
        }

        public bool CanMove(int direstion) // 1-8, 
        {
            int present_x = actualPosition[1];
            int present_y = actualPosition[0];

            int change_in_x = 0;
            int change_in_y = 0;
            switch (direstion)
            {
                case 1:
                    change_in_x = 1;
                    change_in_y = 2;
                    break;
                case 2:
                    change_in_x = 2;
                    change_in_y = 1;
                    break;
                case 3:
                    change_in_x = 2;
                    change_in_y = -1;
                    break;
                case 4:
                    change_in_x = 1;
                    change_in_y = -2;
                    break;
                case 5:
                    change_in_x = -1;
                    change_in_y = -2;
                    break;
                case 6:
                    change_in_x = -2;
                    change_in_y = -1;
                    break;
                case 7:
                    change_in_x = -2;
                    change_in_y = 1;
                    break;
                case 8:
                    change_in_x = -1;
                    change_in_y = 2;
                    break;
            }

            int new_x = present_x + change_in_x;
            int new_y = present_y + change_in_y;

            int[] maybe = new int[2];
            maybe[1] = new_x;
            maybe[0] = new_y;

            if (new_x > 7 || new_x < 0 || new_y > 7 || new_y < 0 ||  //mimo rozmezí
                (alreadyVisited.Contains(maybe) == true && visitedInHowManyMoves[alreadyVisited.IndexOf(maybe)] < moves)  //právě tady porovnávat s TryMoves a finalMoves <- pokud jsme se dostali na stejné místo, ale trvalo nám to více kroků jak jindy, nemá cenu to znova procházet
                || board.cross.Contains(maybe)) //je tam překážka
            {
                return false;
            }

            actualPosition[1] = new_x; 
            actualPosition[0] = new_y;

            moves++;

            alreadyVisited.Add(maybe);
            visitedInHowManyMoves.Add(moves);

            return true;
        }
    }
}



