﻿using Othello_Pluskalova.ViewModel;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Othello_Pluskalova
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();

            // DataContext pro hledání bindingovaných (propojených) vlastností nastavíme na náš ViewModel
            MainWindowViewModel vm = new MainWindowViewModel();
            DataContext = vm;
        }
    }
}