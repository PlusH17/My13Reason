﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Othello_Pluskalova.Model
{
    internal class Card
    {
        public int CordinationX {  get; }

        public int CordinationY { get; }

        public Card(int x, int y) { this.CordinationX = x; this.CordinationY = y; }
        
    }
}
