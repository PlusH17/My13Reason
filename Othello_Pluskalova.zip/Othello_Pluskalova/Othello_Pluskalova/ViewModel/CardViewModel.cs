﻿using Othello_Pluskalova.Model;
using Othello_Pluskalova.MVVM;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Othello_Pluskalova.ViewModel
{
    internal class CardViewModel : ViewModelBase
    {
        public Card Model { get; }
        public CardViewModel(Card card)
        {
            Model = card;
        }



        private bool _white;
        public bool White
        {
            get { return _white; }
            set { _white = value; OnPropertyChanged(); }
        }



        private bool _black;
        public bool Black
        {
            get { return _black; }
            set { _black = value; OnPropertyChanged(); }
        }

        private bool _isPossible;

        public bool IsPossible
        {
            get { return _isPossible; }
            set { _isPossible = value; OnPropertyChanged(); }
        }

        public int CordinationX => Model.CordinationX;
        public int CordinationY => Model.CordinationY;





    }
}
