﻿using Othello_Pluskalova.Model;
using Othello_Pluskalova.MVVM;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Configuration;
using System.Globalization;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Media;
using System.Windows.Threading;
using static System.Runtime.InteropServices.JavaScript.JSType;


namespace Othello_Pluskalova.ViewModel
{
    internal class MainWindowViewModel : ViewModelBase
    {

        public RelayCommand StartCommand => new RelayCommand(execute => StartGame(), canExecute => _isGameRunning == false);
        public RelayCommand CardClickCommand => new RelayCommand(execute => CardClicked(execute as CardViewModel), canExecute => _isGameRunning == true);


        private bool _isGameRunning = false;

        public MainWindowViewModel()
        {
            Cards = new ObservableCollection<CardViewModel>();
            possiblePosition = new List<int>();
            blackPlayerCards = new List<CardViewModel>();
            whitePlayerCards = new List<CardViewModel>();
        }


        #region Potřebnné proměnné + Data Binding

        public int GridSize => (int)Math.Sqrt(Cards.Count);
        private bool firstPlayerPlayed = false;
        private int CardCount = 64;
        private List<int> possiblePosition;
        private List<CardViewModel> blackPlayerCards;
        private List<CardViewModel> whitePlayerCards;
        private bool firstClic = false;


        public ObservableCollection<CardViewModel> Cards { get; set; }


        private string info;

        public string GameInfo
        {
            get { return info; }
            set {
                if (info != value)
                {
                    info = value;
                    OnPropertyChanged();
                }
            }
        }

        #endregion

        #region Herní logika
        private async void StartGame()
        {
            firstPlayerPlayed = false;
            Cards.Clear(); 
            possiblePosition.Clear();
            blackPlayerCards.Clear();
            whitePlayerCards.Clear();
            CreateGameCards();

            GameInfo = "Hra začala, hraje černý";

            _isGameRunning = true;


            Cards[27].White = true;
            whitePlayerCards.Add(Cards[27]);
            Cards[36].White = true;
            whitePlayerCards.Add(Cards[36]);

            Cards[28].Black = true;
            blackPlayerCards.Add(Cards[28]);
            Cards[35].Black = true;
            blackPlayerCards.Add(Cards[35]);

            ShowingPossible();

        }

        private void CardClicked(CardViewModel clicked)
        {
            int positionOfClicked = PositionIndex(clicked);

            if (!possiblePosition.Contains(positionOfClicked))
            {
                GameInfo = "Nepovelené místo"; 
                return; // Pokud to není možný tah, nic nedělej
            }

            // Proveď tah
            if (firstPlayerPlayed == false) // Hraje černý
            {
                clicked.Black = true; clicked.White = false; clicked.IsPossible = false;
                blackPlayerCards.Add(clicked);
                TurnColor(positionOfClicked, blackPlayerCards);
            }
            else // Hraje bílý
            {
                clicked.White = true; clicked.Black = false; clicked.IsPossible = false;
                whitePlayerCards.Add(clicked);
                TurnColor(positionOfClicked, whitePlayerCards);
            }

            firstPlayerPlayed = !firstPlayerPlayed;


            // Aktualizuj info a možné tahy
            if (firstPlayerPlayed == false)
                GameInfo = "Hráč s černými kameny je na tahu";
            else
                GameInfo = "Hráč s bílými kameny je na tahu";

            ShowingPossible();

            if (blackPlayerCards.Count + whitePlayerCards.Count == CardCount || possiblePosition.Count == 0)
            {
                DeterminateWinner();
            }
        }

        private void DeterminateWinner()
        {
            if (blackPlayerCards.Count > whitePlayerCards.Count)
            {
                GameInfo = "vyhrál hráč s černými kamínky";
                _isGameRunning = false;
            }
            else if (blackPlayerCards.Count < whitePlayerCards.Count)
            {
                GameInfo = "vyhrál hráč s bílými kamínky";
                _isGameRunning = false;
            }
            else
            {
                GameInfo = "Remíza";
                _isGameRunning = false;
            }

        }

        private void TurnColor(int positionOfClicked, List<CardViewModel> cardsOfPlayer)
        {
            foreach (CardViewModel card in Cards)
                card.IsPossible = false;
            int XofClic = positionOfClicked % 8;
            int YofClic = (positionOfClicked-XofClic)/8;

            foreach (var card in cardsOfPlayer.ToList())
            {
                int positionOfCard = PositionIndex(card);
                if (card.CordinationX == XofClic) //Sloupec
                {
                    int start = Math.Min(positionOfCard, positionOfClicked);
                    int end = Math.Max(positionOfCard, positionOfClicked);

                    for (int i = start + 8; i < end; i += 8)
                    {
                        if (firstPlayerPlayed == false)
                        {
                            Cards[i].Black = true; Cards[i].White = false;
                            if (!blackPlayerCards.Contains(Cards[i])) blackPlayerCards.Add(Cards[i]);
                            whitePlayerCards.Remove(Cards[i]);
                        }
                        else
                        {
                            Cards[i].White = true; Cards[i].Black = false;
                            if (!whitePlayerCards.Contains(Cards[i])) whitePlayerCards.Add(Cards[i]);
                            blackPlayerCards.Remove(Cards[i]);
                        }
                    }
                }

                if (card.CordinationY == YofClic) //řádek
                {
                    int start = Math.Min(positionOfCard, positionOfClicked);
                    int end = Math.Max(positionOfCard, positionOfClicked);

                    for (int i = start + 1; i < end; i += 1)
                    {
                        if (firstPlayerPlayed == false)
                        {
                            Cards[i].Black = true; Cards[i].White = false;
                            if (!blackPlayerCards.Contains(Cards[i])) blackPlayerCards.Add(Cards[i]);
                            whitePlayerCards.Remove(Cards[i]);
                        }
                        else
                        {
                            Cards[i].White = true; Cards[i].Black = false;
                            if (!whitePlayerCards.Contains(Cards[i])) whitePlayerCards.Add(Cards[i]);
                            blackPlayerCards.Remove(Cards[i]);
                        }
                    }
                }


                if (positionOfClicked % 9 == positionOfCard % 9) //Diagonála o -> 9
                {
                    bool valid = true;
                    int start = Math.Min(positionOfCard, positionOfClicked);
                    int end = Math.Max(positionOfCard, positionOfClicked);

                    for (int i = start + 9; i < end; i += 9)
                    {
                        if (i % 8 == 7 && i + 9 < end)
                            valid = false;
                    }

                    if (valid == true)
                    {
                        for (int i = start + 9; i < end; i += 9)
                        {

                        if (firstPlayerPlayed == false)
                        {
                            Cards[i].Black = true; Cards[i].White = false;
                            if (!blackPlayerCards.Contains(Cards[i])) blackPlayerCards.Add(Cards[i]);
                            whitePlayerCards.Remove(Cards[i]);
                        }
                        else
                        {
                            Cards[i].White = true; Cards[i].Black = false;
                            if (!whitePlayerCards.Contains(Cards[i])) whitePlayerCards.Add(Cards[i]);
                            blackPlayerCards.Remove(Cards[i]);
                        }
                        }
                    }
                    
                }

                if (positionOfClicked % 7 == positionOfCard % 7) //Diagonála 7 -> 14 (Opraveno z 9 na 7)
                {
                    bool valid = true;

                    int start = Math.Min(positionOfCard, positionOfClicked);
                    int end = Math.Max(positionOfCard, positionOfClicked);

                    for (int i = start + 7; i < end; i += 7)
                    {
                        if (i % 8 == 0 && i + 7 < end)
                            valid = false;
                    }
                    if (valid)
                    {
                        for (int i = start + 7; i < end; i += 7)
                        {
                            if (firstPlayerPlayed == false)
                            {
                                Cards[i].Black = true; Cards[i].White = false;
                                if (!blackPlayerCards.Contains(Cards[i])) blackPlayerCards.Add(Cards[i]);
                                whitePlayerCards.Remove(Cards[i]);
                            }
                            else
                            {
                                Cards[i].White = true; Cards[i].Black = false;
                                if (!whitePlayerCards.Contains(Cards[i])) whitePlayerCards.Add(Cards[i]);
                                blackPlayerCards.Remove(Cards[i]);
                            }
                        }
                    }
                }


            }

        }

        private void CreateGameCards() //přidáme karty
        {
            for (int i = 0; i < CardCount; i++)
            {
                int positionX = i % 8;
                int positiony = (i - (i % 8)) / 8;

                Cards.Add(new CardViewModel(new Card(positionX, positiony)));
            }
        }

        private int PositionIndex(CardViewModel clicked)
        {
            int x = clicked.CordinationX;
            int y = clicked.CordinationY;
            return x + 8 * y;
        }

        private void ShowingPossible()
        {
            possiblePosition.Clear();
            foreach (CardViewModel card in Cards)
                card.IsPossible = false;
            if (firstPlayerPlayed == false) //na tahu černý
            {
                foreach (CardViewModel card in blackPlayerCards)
                {
                    // 1.Kontrola <--
                    if (card.CordinationX % 8 != 0 && card.CordinationX % 8 != 1) //je zbytečný řešit krajní a hned vedle kraje
                    {
                        int position = PositionIndex(card);
                        if (Cards[position-1].White == true) //pokud vpravo je bílá
                        {
                            for (int i = position-2; i%8!=7 ; i--) //hledáme tu vedle pravé co je "VOLNÁ" na označení
                            {
                                if (i >= 63) break;

                                if (Cards[i].Black) break;
                                if (Cards[i].White== false && Cards[i].Black == false)
                                {
                                    Cards[i].IsPossible = true; //našli jsme ji
                                    possiblePosition.Add(i);
                                    break;
                                }
                            }
                        }
                    }
                    // 2.Kontrola -->
                    if (card.CordinationX % 8 != 6 && card.CordinationX % 8 != 7) //je zbytečný řešit krajní a hned vedle kraje
                    {
                        int position = PositionIndex(card);
                        if (Cards[position+1].White == true) //pokud vlevo je bílá
                        {
                            for (int i = position+2; i%8!=0 ; i++) //hledáme tu vedle pravé co je "VOLNÁ" na označení
                            {
                                if (i >= 63) break;
                                if (Cards[i].Black) break;
                                if (Cards[i].White== false && Cards[i].Black == false)
                                {
                                    Cards[i].IsPossible = true; //našli jsme ji
                                    possiblePosition.Add(i);
                                    break;
                                }
                            }
                        }

                    }
                    // 3.Kontrola ^
                    if (card.CordinationY != 0 && card.CordinationY != 1) //je zbytečný řešit krajní a hned vedle kraje
                    {
                        int position = PositionIndex(card);
                        if (Cards[position - 8].White == true) //pokud nahoře je bílá
                        {
                            for (int i = card.CordinationY - 2; i != 0; i--) //hledáme tu vedle horní co je "VOLNÁ" na označení
                            {

                                int index = card.CordinationX + i * 8;
                                if (index >= 63) break;

                                if (Cards[index].Black) break;
                                if (Cards[index].White == false && Cards[index].Black == false)
                                {
                                    Cards[index].IsPossible = true; //našli jsme ji
                                    possiblePosition.Add(index);
                                    break;
                                }
                            }
                        }

                    }
                    // 4.Kontrola ďolu
                    if (card.CordinationY != 6 && card.CordinationY != 7) //je zbytečný řešit krajní a hned vedle kraje
                    {
                        int position = PositionIndex(card);
                        if (Cards[position + 8].White == true) //pokud DOLE je bílá
                        {
                            for (int i = card.CordinationY + 2; i != 7; i++) //hledáme tu vedle horní co je "VOLNÁ" na označení
                            {
                                if (i >= 63) break;

                                int index = card.CordinationX + i * 8;
                                if (Cards[index].Black) break;
                                if (Cards[index].White == false && Cards[index].Black == false)
                                {
                                    Cards[index].IsPossible = true; //našli jsme ji
                                    possiblePosition.Add(index);
                                    break;
                                }
                            }
                        }

                    }

                    //5.Kontrolo vlevo nahoru
                    if (card.CordinationX % 8 != 0 && card.CordinationX % 8 != 1 && card.CordinationY != 0 && card.CordinationY != 1) //je zbytečný řešit krajní a hned vedle kraje
                    {
                        int position = PositionIndex(card);
                        if (Cards[position - 9].White == true) //pokud vlevonaho5e je bílá
                        {
                            for (int i = position - 18; i >= 0; i-=9) //hledáme tu vedle pravé co je "VOLNÁ" na označení
                            {
                                if (i >= 63) break;

                                if (Cards[i].Black) break;
                                if (Cards[i].White == false && Cards[i].Black == false)
                                {
                                    Cards[i].IsPossible = true; //našli jsme ji
                                    possiblePosition.Add(i);
                                    break;
                                }


                            }
                        }
                    }
                    // 6.Kontrola vpravo dolu
                    if (card.CordinationX <= 5 && card.CordinationY <= 5)
                    {
                        int position = PositionIndex(card);
                        if (Cards[position + 9].White == true)
                        {
                            for (int i = position + 18; i <= 63; i += 9)
                            {
                                if (i >= 63) break;

                                if (i % 8 == 0) break;

                                if (Cards[i].Black) break; // Narazili jsme na vlastní barvu
                                if (Cards[i].White == false && Cards[i].Black == false)
                                {
                                    Cards[i].IsPossible = true;
                                    possiblePosition.Add(i);
                                    break;
                                }

                                // Pokud jsme na posledním možném indexu v tomto směru, ukončíme
                                if (i >= 56 || i % 8 == 7) break;
                            }
                        }
                    }
                    //7. Kontrola vpravo naoru
                    if (card.CordinationX % 8 != 6 && card.CordinationX % 8 != 7 && card.CordinationY != 0 && card.CordinationY != 1) //je zbytečný řešit krajní a hned vedle kraje
                    {
                        int position = PositionIndex(card);
                        if (Cards[position - 7].White == true) //pokud vlevonaho5e je bílá
                        {
                            for (int i = position - 14; i >= 0; i-=7) //hledáme tu vedle pravé co je "VOLNÁ" na označení
                            {
                                if (i >= 63) break;

                                if (Cards[i].Black) break;
                                if (Cards[i].White == false && Cards[i].Black == false)
                                {
                                    Cards[i].IsPossible = true; //našli jsme ji
                                    possiblePosition.Add(i);
                                    break;
                                }


                            }
                        }
                    }
                    // 8.Kontrola vlevo dolu
                    if (card.CordinationX >=2 && card.CordinationY <= 5) //je zbytečný řešit krajní a hned vedle kraje
                    {
                        int position = PositionIndex(card);
                        if (Cards[position + 7].White == true) //pokud vlevonaho5e je bílá
                        {
                            for (int i = position + 14; i <= 63; i += 7) //hledáme tu vedle pravé co je "VOLNÁ" na označení
                            {
                                if (i >= 63) break;

                                if (Cards[i].Black) break;
                                if (Cards[i].White == false && Cards[i].Black == false)
                                {
                                    Cards[i].IsPossible = true; //našli jsme ji
                                    possiblePosition.Add(i);
                                    break;
                                }

                            }
                        }
                    }


                }
            }
            else if (firstPlayerPlayed == true) //na tahu bílý
            {
                foreach (CardViewModel card in whitePlayerCards)
                {
                    // 1.Kontrola <--
                    if (card.CordinationX % 8 != 0 && card.CordinationX % 8 != 1) //je zbytečný řešit krajní a hned vedle kraje
                    {
                        int position = PositionIndex(card);
                        if (Cards[position-1].Black == true) //pokud vpravo je černý
                        {
                            for (int i = position-2; i%8!=7 ; i--) //hledáme tu vedle pravé co je "VOLNÁ" na označení
                            {
                                if (i >= 63) break;

                                if (Cards[i].White) break;
                                if (Cards[i].White== false && Cards[i].Black == false)
                                {
                                    Cards[i].IsPossible = true; //našli jsme ji
                                    possiblePosition.Add(i);
                                    break;
                                }
                            }
                        }
                    }
                    // 2.Kontrola -->
                    if (card.CordinationX % 8 != 6 && card.CordinationX % 8 != 7) //je zbytečný řešit krajní a hned vedle kraje
                    {
                        int position = PositionIndex(card);
                        if (Cards[position+1].Black == true) //pokud vlevo je černý
                        {
                            for (int i = position+2; i%8!=0 ; i++) //hledáme tu vedle pravé co je "VOLNÁ" na označení
                            {
                                if (i >= 63) break;

                                if (Cards[i].White) break;

                                if (Cards[i].White== false && Cards[i].Black == false)
                                {
                                    Cards[i].IsPossible = true; //našli jsme ji
                                    possiblePosition.Add(i);
                                    break;
                                }
                            }
                        }

                    }
                    // 3.Kontrola ^
                    if (card.CordinationY != 0 && card.CordinationY != 1) //je zbytečný řešit krajní a hned vedle kraje
                    {
                        int position = PositionIndex(card);
                        if (Cards[position - 8].Black == true) //pokud nahoře je černý
                        {
                            for (int i = card.CordinationY - 2; i != 0; i--) //hledáme tu vedle horní co je "VOLNÁ" na označení
                            {
                                if (i >= 63) break;

                                int index = card.CordinationX + i * 8;
                                if (Cards[index].White) break;

                                if (Cards[index].White == false && Cards[index].Black == false)
                                {
                                    Cards[index].IsPossible = true; //našli jsme ji
                                    possiblePosition.Add(index);
                                    break;
                                }
                            }
                        }

                    }
                    // 4.Kontrola ďolu
                    if (card.CordinationY != 6 && card.CordinationY != 7) //je zbytečný řešit krajní a hned vedle kraje
                    {
                        int position = PositionIndex(card);
                        if (Cards[position + 8].Black == true) //pokud DOLE je černý
                        {
                            for (int i = card.CordinationY + 2; i != 7; i++) //hledáme tu vedle horní co je "VOLNÁ" na označení
                            {
                                if (i >= 63) break;

                                int index = card.CordinationX + i * 8;
                                if (Cards[index].White) break;

                                if (Cards[index].White == false && Cards[index].Black == false)
                                {
                                    Cards[index].IsPossible = true; //našli jsme ji
                                    possiblePosition.Add(index);
                                    break;
                                }
                            }
                        }

                    }

                    //5.Kontrolo vlevo nahoru
                    if (card.CordinationX % 8 != 0 && card.CordinationX % 8 != 1 && card.CordinationY != 0 && card.CordinationY != 1) //je zbytečný řešit krajní a hned vedle kraje
                    {
                        int position = PositionIndex(card);
                        if (Cards[position - 9].Black == true) //pokud vlevonaho5e je černá
                        {
                            for (int i = position - 18; i >= 0; i -= 9) //hledáme tu vedle pravé co je "VOLNÁ" na označení
                            {
                                if (i >= 63) break;

                                if (Cards[i].White == false && Cards[i].Black == false)
                                {
                                    if (Cards[i].White) break;

                                    Cards[i].IsPossible = true; //našli jsme ji
                                    possiblePosition.Add(i);
                                    break;
                                }


                            }
                        }
                    }
                    // 6.Kontrola vpravo dolu
                    if (card.CordinationX <= 5 && card.CordinationY <= 5)
                    {
                        int position = PositionIndex(card);
                        if (Cards[position + 9].Black == true)
                        {
                            for (int i = position + 18; i <= 63; i += 9)
                            {
                                // Ošetření přetečení řádku (vpravo)
                                if (i >= 63) break;

                                if (i % 8 == 0) break;

                                if (Cards[i].Black) break; // Narazili jsme na vlastní barvu
                                if (Cards[i].White == false && Cards[i].Black == false)
                                {
                                    Cards[i].IsPossible = true;
                                    possiblePosition.Add(i);
                                    break;
                                }

                                // Pokud jsme na posledním možném indexu v tomto směru, ukončíme
                                if (i >= 56 || i % 8 == 7) break;
                            }
                        }
                    }
                    //7. Kontrola vpravo naoru
                    if (card.CordinationX % 8 != 6 && card.CordinationX % 8 != 7 && card.CordinationY != 0 && card.CordinationY != 1) //je zbytečný řešit krajní a hned vedle kraje
                    {
                        int position = PositionIndex(card);
                        if (Cards[position - 7].Black == true) //pokud vlevonaho5e je bílá
                        {
                            for (int i = position - 14; i >= 0; i -= 7) //hledáme tu vedle pravé co je "VOLNÁ" na označení
                            {
                                if (Cards[i].White) break;


                                if (Cards[i].White == false && Cards[i].Black == false)
                                {
                                    Cards[i].IsPossible = true; //našli jsme ji
                                    possiblePosition.Add(i);
                                    break;
                                }


                            }
                        }
                    }
                    // 8.Kontrola vlevo dolu
                    if (card.CordinationX >= 2 && card.CordinationY <= 5) //je zbytečný řešit krajní a hned vedle kraje
                    {
                        int position = PositionIndex(card);
                        if (Cards[position + 7].Black == true) //pokud vlevonaho5e je bílá
                        {
                            for (int i = position + 14; i <= 63; i += 7) //hledáme tu vedle pravé co je "VOLNÁ" na označení
                            {
                                if (Cards[i].White) break;

                                if (Cards[i].White == false && Cards[i].Black == false)
                                {
                                    Cards[i].IsPossible = true; //našli jsme ji
                                    possiblePosition.Add(i);
                                    break;
                                }

                            }
                        }
                    }


                }
            }
                
        }
        #endregion
    }
}
